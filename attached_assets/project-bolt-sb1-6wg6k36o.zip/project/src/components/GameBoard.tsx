import React from 'react';
import { GameState, Direction } from '../types/game';
import { TERRAIN_COLORS } from '../config/terrain';
import { MapIcon, Droplets, Cookie, Coins } from 'lucide-react';

interface GameBoardProps {
  gameState: GameState;
  onMove: (direction: Direction) => void;
  onRest: () => void;
}

export const GameBoard: React.FC<GameBoardProps> = ({ gameState, onMove, onRest }) => {
  const { map, player, turn } = gameState;

  return (
    <div className="p-4">
      <div className="mb-4 grid grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold mb-2">Status</h3>
          <div className="grid grid-cols-2 gap-2">
            <div className="flex items-center">
              <MapIcon className="w-5 h-5 mr-2" />
              <span>Strength: {player.currentStrength}/{player.maxStrength}</span>
            </div>
            <div className="flex items-center">
              <Droplets className="w-5 h-5 mr-2" />
              <span>Water: {player.currentWater}/{player.maxWater}</span>
            </div>
            <div className="flex items-center">
              <Cookie className="w-5 h-5 mr-2" />
              <span>Food: {player.currentFood}/{player.maxFood}</span>
            </div>
            <div className="flex items-center">
              <Coins className="w-5 h-5 mr-2" />
              <span>Gold: {player.currentGold}</span>
            </div>
          </div>
          <div className="mt-2">
            <span className="text-sm text-gray-600">Turn: {turn}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold mb-2">Controls</h3>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => onMove('northwest')}
              className="p-2 bg-gray-100 rounded hover:bg-gray-200"
            >
              ↖
            </button>
            <button
              onClick={() => onMove('north')}
              className="p-2 bg-gray-100 rounded hover:bg-gray-200"
            >
              ↑
            </button>
            <button
              onClick={() => onMove('northeast')}
              className="p-2 bg-gray-100 rounded hover:bg-gray-200"
            >
              ↗
            </button>
            <button
              onClick={() => onMove('west')}
              className="p-2 bg-gray-100 rounded hover:bg-gray-200"
            >
              ←
            </button>
            <button
              onClick={onRest}
              className="p-2 bg-yellow-100 rounded hover:bg-yellow-200"
            >
              Rest
            </button>
            <button
              onClick={() => onMove('east')}
              className="p-2 bg-gray-100 rounded hover:bg-gray-200"
            >
              →
            </button>
            <button
              onClick={() => onMove('southwest')}
              className="p-2 bg-gray-100 rounded hover:bg-gray-200"
            >
              ↙
            </button>
            <button
              onClick={() => onMove('south')}
              className="p-2 bg-gray-100 rounded hover:bg-gray-200"
            >
              ↓
            </button>
            <button
              onClick={() => onMove('southeast')}
              className="p-2 bg-gray-100 rounded hover:bg-gray-200"
            >
              ↘
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white p-4 rounded-lg shadow-md overflow-auto">
        <div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${map[0].length}, minmax(40px, 1fr))` }}>
          {map.map((row, y) =>
            row.map((cell, x) => (
              <div
                key={`${x}-${y}`}
                className={`
                  ${TERRAIN_COLORS[cell.terrain]}
                  w-10 h-10 rounded-sm
                  flex items-center justify-center
                  ${player.x === x && player.y === y ? 'ring-2 ring-blue-500' : ''}
                `}
              >
                {cell.items.length > 0 && !cell.items[0].collected && (
                  <span className="text-xs">
                    {cell.items[0].type === 'food' && '🍖'}
                    {cell.items[0].type === 'water' && '💧'}
                    {cell.items[0].type === 'gold' && '💰'}
                    {cell.items[0].type === 'trader' && '👨'}
                  </span>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};