import React, { useState } from 'react';
import { GameState } from '../types/game';

interface GameSetupProps {
  onStart: (width: number, height: number, difficulty: GameState['difficulty']) => void;
}

export const GameSetup: React.FC<GameSetupProps> = ({ onStart }) => {
  const [width, setWidth] = useState(20);
  const [height, setHeight] = useState(10);
  const [difficulty, setDifficulty] = useState<GameState['difficulty']>('medium');

  return (
    <div className="bg-white p-8 rounded-lg shadow-md max-w-md mx-auto">
      <h2 className="text-2xl font-bold mb-6">Wilderness Survival System</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Map Width (squares)
          </label>
          <input
            type="number"
            min="10"
            max="30"
            value={width}
            onChange={(e) => setWidth(Number(e.target.value))}
            className="w-full px-3 py-2 border rounded-md"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Map Height (squares)
          </label>
          <input
            type="number"
            min="5"
            max="20"
            value={height}
            onChange={(e) => setHeight(Number(e.target.value))}
            className="w-full px-3 py-2 border rounded-md"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Difficulty
          </label>
          <select
            value={difficulty}
            onChange={(e) => setDifficulty(e.target.value as GameState['difficulty'])}
            className="w-full px-3 py-2 border rounded-md"
          >
            <option value="easy">Easy</option>
            <option value="medium">Medium</option>
            <option value="hard">Hard</option>
          </select>
        </div>

        <button
          onClick={() => onStart(width, height, difficulty)}
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
        >
          Start Game
        </button>
      </div>
    </div>
  );
};