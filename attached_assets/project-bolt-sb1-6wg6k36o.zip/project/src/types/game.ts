export type TerrainType = 'plains' | 'mountain' | 'desert' | 'swamp' | 'forest';

export interface Costs {
  movement: number;
  water: number;
  food: number;
}

export interface Item {
  type: 'food' | 'water' | 'gold' | 'trader';
  amount: number;
  repeating: boolean;
  collected: boolean;
}

export interface Cell {
  terrain: TerrainType;
  items: Item[];
  x: number;
  y: number;
}

export interface Player {
  x: number;
  y: number;
  maxStrength: number;
  maxWater: number;
  maxFood: number;
  currentStrength: number;
  currentWater: number;
  currentFood: number;
  currentGold: number;
}

export interface GameState {
  map: Cell[][];
  player: Player;
  width: number;
  height: number;
  difficulty: 'easy' | 'medium' | 'hard';
  turn: number;
}

export type Direction = 'north' | 'south' | 'east' | 'west' | 'northeast' | 'northwest' | 'southeast' | 'southwest';