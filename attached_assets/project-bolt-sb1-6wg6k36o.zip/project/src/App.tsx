import React from 'react';
import { GameSetup } from './components/GameSetup';
import { GameBoard } from './components/GameBoard';
import { useGame } from './hooks/useGame';

function App() {
  const { gameState, startGame, move, rest } = useGame();

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      {!gameState ? (
        <GameSetup onStart={startGame} />
      ) : (
        <GameBoard
          gameState={gameState}
          onMove={move}
          onRest={rest}
        />
      )}
    </div>
  );
}

export default App;