import { useState, useCallback } from 'react';
import { GameState, TerrainType, Direction, Cell, Player } from '../types/game';
import { TERRAIN_COSTS } from '../config/terrain';

const generateMap = (width: number, height: number, difficulty: GameState['difficulty']): Cell[][] => {
  const map: Cell[][] = [];
  const terrainTypes: TerrainType[] = ['plains', 'mountain', 'desert', 'swamp', 'forest'];
  
  for (let y = 0; y < height; y++) {
    const row: Cell[] = [];
    for (let x = 0; x < width; x++) {
      // Simple terrain generation - can be made more sophisticated
      const terrainIndex = Math.floor(Math.random() * terrainTypes.length);
      row.push({
        terrain: terrainTypes[terrainIndex],
        items: [],
        x,
        y,
      });
    }
    map.push(row);
  }

  // Add items based on difficulty
  const itemCount = difficulty === 'easy' ? 10 : difficulty === 'medium' ? 7 : 5;
  for (let i = 0; i < itemCount; i++) {
    const x = Math.floor(Math.random() * width);
    const y = Math.floor(Math.random() * height);
    const itemTypes = ['food', 'water', 'gold', 'trader'] as const;
    const itemType = itemTypes[Math.floor(Math.random() * itemTypes.length)];
    
    map[y][x].items.push({
      type: itemType,
      amount: Math.floor(Math.random() * 3) + 1,
      repeating: Math.random() < 0.3,
      collected: false,
    });
  }

  return map;
};

const createInitialPlayer = (): Player => ({
  x: 0,
  y: Math.floor(Math.random() * 10),
  maxStrength: 20,
  maxWater: 15,
  maxFood: 15,
  currentStrength: 20,
  currentWater: 15,
  currentFood: 15,
  currentGold: 0,
});

export const useGame = () => {
  const [gameState, setGameState] = useState<GameState | null>(null);

  const startGame = useCallback((width: number, height: number, difficulty: GameState['difficulty']) => {
    const map = generateMap(width, height, difficulty);
    const player = createInitialPlayer();
    
    setGameState({
      map,
      player,
      width,
      height,
      difficulty,
      turn: 1,
    });
  }, []);

  const move = useCallback((direction: Direction) => {
    if (!gameState) return;

    const { player, map } = gameState;
    let newX = player.x;
    let newY = player.y;

    // Calculate new position
    switch (direction) {
      case 'north':
        newY = Math.max(0, player.y - 1);
        break;
      case 'south':
        newY = Math.min(gameState.height - 1, player.y + 1);
        break;
      case 'east':
        newX = Math.min(gameState.width - 1, player.x + 1);
        break;
      case 'west':
        newX = Math.max(0, player.x - 1);
        break;
      case 'northeast':
        newY = Math.max(0, player.y - 1);
        newX = Math.min(gameState.width - 1, player.x + 1);
        break;
      case 'northwest':
        newY = Math.max(0, player.y - 1);
        newX = Math.max(0, player.x - 1);
        break;
      case 'southeast':
        newY = Math.min(gameState.height - 1, player.y + 1);
        newX = Math.min(gameState.width - 1, player.x + 1);
        break;
      case 'southwest':
        newY = Math.min(gameState.height - 1, player.y + 1);
        newX = Math.max(0, player.x - 1);
        break;
    }

    // Get costs for the new terrain
    const newTerrain = map[newY][newX].terrain;
    const costs = TERRAIN_COSTS[newTerrain];

    // Check if player has enough resources
    if (
      player.currentStrength >= costs.movement &&
      player.currentWater >= costs.water &&
      player.currentFood >= costs.food
    ) {
      setGameState({
        ...gameState,
        player: {
          ...player,
          x: newX,
          y: newY,
          currentStrength: Math.min(player.maxStrength, player.currentStrength - costs.movement),
          currentWater: Math.min(player.maxWater, player.currentWater - costs.water),
          currentFood: Math.min(player.maxFood, player.currentFood - costs.food),
        },
        turn: gameState.turn + 1,
      });
    }
  }, [gameState]);

  const rest = useCallback(() => {
    if (!gameState) return;

    const { player } = gameState;
    const currentTerrain = gameState.map[player.y][player.x].terrain;
    const costs = TERRAIN_COSTS[currentTerrain];

    setGameState({
      ...gameState,
      player: {
        ...player,
        currentStrength: Math.min(player.maxStrength, player.currentStrength + 2),
        currentWater: Math.min(player.maxWater, player.currentWater - costs.water / 2),
        currentFood: Math.min(player.maxFood, player.currentFood - costs.food / 2),
      },
      turn: gameState.turn + 1,
    });
  }, [gameState]);

  return {
    gameState,
    startGame,
    move,
    rest,
  };
};