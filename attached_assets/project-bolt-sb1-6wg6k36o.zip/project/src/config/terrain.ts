import { TerrainType, Costs } from '../types/game';

export const TERRAIN_COSTS: Record<TerrainType, Costs> = {
  plains: {
    movement: 1,
    water: 1,
    food: 1,
  },
  mountain: {
    movement: 3,
    water: 2,
    food: 2,
  },
  desert: {
    movement: 2,
    water: 3,
    food: 1,
  },
  swamp: {
    movement: 2,
    water: 1,
    food: 2,
  },
  forest: {
    movement: 2,
    water: 1,
    food: 1,
  },
};

export const TERRAIN_COLORS: Record<TerrainType, string> = {
  plains: 'bg-green-200',
  mountain: 'bg-gray-400',
  desert: 'bg-yellow-200',
  swamp: 'bg-green-700',
  forest: 'bg-green-500',
};